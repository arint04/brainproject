import { loading } from "../assets";

const Generating = ({ className }) => {

};

export default Generating;
